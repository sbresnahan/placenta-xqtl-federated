placenta-xqtl-federated restricted file, version 1
Prepared by MD Anderson Cancer Center (Bhattacharya Lab).
For use by approved participating cohorts only, under their data-sharing agreement.
Do not redistribute. Place the archive at the path given by 'restricted' in cohort.yml.
